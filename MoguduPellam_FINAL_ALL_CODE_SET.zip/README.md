# Mogudu Pellam — Premium Pin-to-Pin Features

Premium romantic couple game UI based on the supplied reference design.

Included: splash + welcome + couple setup, premium dashboard, game selection, 100+ couple questions, 50 Truths, 50 Dares, 50 Couple Challenges, 50 Funny Punishments, 35 Birthday Wishes, 35 Anniversary Wishes, Daily Love Message, Spin the Wheel, Love Meter, XP/Levels/Achievements, Coins/Rewards, Memories + Captions, enhanced Our Love Story + shareable story card, Surprise Box, music/sound effects, hearts/confetti/animations, score board, round results, final compatibility result, profile/more, sharing, dark/light mode.

The GitHub Actions workflow extracts this ZIP and builds the debug APK.
