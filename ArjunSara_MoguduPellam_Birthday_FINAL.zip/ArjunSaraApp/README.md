# Arjun & Sara – Mogudu & Pellam

Android couple fun game project.

## Build

Open this folder in Android Studio and sync Gradle. The included GitHub Actions workflow builds the debug APK using Gradle 8.7 and JDK 17; it does not require a checked-in `gradlew` wrapper.

GitHub Actions artifact: `ArjunSara-debug-apk`.
