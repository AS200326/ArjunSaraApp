# Mogudu Pellam – Reference Style Final

This project implements the Mogudu Pellam app UI as a functional Android app inspired by the supplied reference design. The reference image is not embedded in the app.

Key UI upgrades:
- Dark navy/purple premium background
- White/pale-pink rounded cards
- Glossy pink action buttons
- Large couple avatars and names
- Bottom navigation: Home / Score / Rewards / Profile
- Reference-style home dashboard grid
- Reference-style question, challenge, round result, score board, final result and punishment screens
- 35 Birthday Wishes and 35 Anniversary Wishes
- Existing games, memories, love story, rewards, settings, animations, music and sharing preserved
