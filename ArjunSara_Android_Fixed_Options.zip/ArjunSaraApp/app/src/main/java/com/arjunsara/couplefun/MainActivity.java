package com.arjunsara.couplefun;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, subtitle;
    int qIndex=0, score=0, arjunChoice=-1;
    boolean answeringArjun=true;
    String arjun="Arjun", sara="Sara";
    CountDownTimer timer;
    int challengeScore=0;

    final String[] questions={
        "Who gets more sleep?","Who wakes up late?","Who uses the phone more?","Who shops more?","Who takes more selfies?","Who loves chocolates more?","Who watches more movies?","Who loves travelling more?","Who calls first after a fight?","Who gets jealous more?","Who is more romantic?","Who loves surprises more?","Who makes more jokes?","Who gets angry faster?","Who smiles first after a fight?","Who gives more compliments?","Who spends more money?","Who loves the beach more?","Who loves the mountains more?","Who remembers birthdays better?","Who says '5 minutes' and comes late?","Who is more dramatic?","Who is more stubborn?","Who is more emotional?","Who is the real Boss? 👑","Who says sorry first?","Who sends more good-morning messages?","Who sends more good-night messages?","Who replies faster to messages?","Who leaves messages on read?","Who makes the better food choice?","Who steals food from the partner's plate?","Who orders more food?","Who loves spicy food more?","Who has a sweeter tooth?","Who sings more often?","Who dances more often?","Who is more likely to sing in the shower?","Who laughs louder?","Who tells more silly jokes?","Who is more likely to forget where they kept something?","Who loses keys more often?","Who forgets appointments more often?","Who remembers small details better?","Who is more organized?","Who is more adventurous?","Who is more careful?","Who is more competitive?","Who is more patient?","Who is more stubborn during an argument?","Who is more likely to start a conversation?","Who talks more on calls?","Who sends longer messages?","Who uses more emojis? 😂","Who sends more reels?","Who is more likely to plan a surprise date?","Who is better at choosing gifts?","Who gives better hugs?","Who gives better compliments?","Who is more affectionate?","Who gets embarrassed more easily?","Who cries more during emotional movies?","Who gets excited more easily?","Who worries more?","Who is more confident?","Who is more likely to take a long time getting ready?","Who checks the mirror more often?","Who takes more photos before choosing one?","Who changes outfits more often?","Who has better fashion sense?","Who is more likely to suggest a long drive?","Who is more likely to suggest a movie night?","Who is more likely to plan a holiday?","Who would choose the beach for a date?","Who would choose the mountains for a date?","Who is more likely to buy something cute for the partner?","Who is more likely to remember the first date?","Who remembers the first 'I Love You' better?","Who is more likely to keep old photos?","Who is more likely to save romantic messages?","Who gets jealous when the partner talks to someone else?","Who is more protective?","Who is more possessive?","Who forgives faster?","Who makes peace after a fight?","Who is more likely to say 'I miss you' first?","Who is more likely to say 'I love you' first?","Who is more likely to call just to hear the partner's voice?","Who is more likely to plan an anniversary surprise?","Who is more likely to write a love note?","Who is more likely to win a couple challenge?","Who is more likely to cheat at a game? 😂","Who celebrates small wins more?","Who is more likely to make the partner laugh when sad?","Who is the ultimate boss of this relationship? 👑","Who is more likely to choose love over money? ❤️","Who is more likely to plan a secret date? 🤫","Who is more likely to make the partner laugh during a serious moment? 😂","Who is more likely to keep the relationship photo as their wallpaper? 📱❤️","Who is more likely to say 'One more episode' and stay up late? 🍿"
    };

    final String[] truths={
        "Partner lo first ga nachina thing enti? ❤️","Partner meeda eppudaina jealous feel ayyava? 😜","Mee first impression enti?","Partner ki cheppani cute secret enti? 🤫","Partner lo most attractive quality enti? 😍","Mee best memory together enti?","Fight ayyaka first ga evarini miss avuthav?","Partner ki nuvvu change cheyyali anukune funny habit enti? 😂","Future lo partner tho ekkadiki vellali anukuntunnav? ✈️","Partner kosam chesina sweetest thing enti?"
    };
    final String[] dares={
        "20 seconds partner ni praise cheyyali ❤️","Funny dance 20 seconds cheyyali 😂","Partner ni 15 seconds imitate cheyyali 🤣","‘I Love You’ 5 different styles lo cheppali 😘","Partner ki oka cute dialogue cheppali 💕","Partner favourite song lo 10 seconds hum cheyyali 🎵","Partner ni chusi 15 seconds smile cheyyali 😊","Oka funny selfie pose cheyyali 📸","Partner ki 3 cute nicknames immediate ga cheppali 😍","Partner ni make-up ad laaga praise cheyyali 😂"
    };
    final String[] challenges={
        "Staring Challenge 👀 — 30 sec eye contact, no laughing!","No Laugh Challenge 😂 — 30 sec serious face maintain cheyyandi!","Song Challenge 🎵 — Partner favourite song guess cheyyandi!","Memory Challenge 🧠 — First date details cheppandi!","Imitation Challenge 🤣 — Partner mannerisms imitate cheyyandi!","Compliment Challenge ❤️ — 20 sec lo maximum compliments!","Emoji Challenge 😍 — Only emojis tho oka message explain cheyyandi!","Pose Challenge 📸 — Same pose lo perfect selfie teesukondi!"
    };
    final String[] punishments={
        "Partner ki 5 compliments ivvali 💕","10-sec funny dance cheyyali 💃","Partner favourite dialogue imitate cheyyali 🤣","Partner ni 20-sec hug cheyyali 🤗","One cute apology cheppali 😘","Partner kosam oka sweet promise cheyyali ❤️"
    };

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }

    TextView tv(String text,int size){ TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); t.setPadding(16,12,16,12); return t; }
    Button btn(String text){ Button b=new Button(this); b.setText(text); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(16,8,16,8); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(233,30,99)); g.setCornerRadius(60); b.setBackground(g); int h=(int)(60*getResources().getDisplayMetrics().density); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h); p.setMargins(20,6,20,6); b.setLayoutParams(p); return b; }
    void base(String heading,String sub){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(27,18,48),Color.rgb(106,27,154)}); root.setBackground(bg);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER_HORIZONTAL); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        title=tv(heading,30); title.setTypeface(null,1); content.addView(title); subtitle=tv(sub,16); content.addView(subtitle);
        animate(title);
    }
    void animate(View v){ v.setAlpha(0f); v.setScaleX(.94f); v.setScaleY(.94f); v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).start(); }
    void addHeartBurst(){
        TextView hearts=tv("❤️  💕  💖  💗  💓  💕  ❤️",25); content.addView(hearts); hearts.animate().alpha(0f).translationY(-25).setDuration(900).start();
    }
    void showHome(){
        base("Arjun & Sara ❤️","Couple Fun Game • Love lo gelupu… Fun lo rendu!");
        
        Button start=btn("❤️ Start Game"); start.setOnClickListener(v->showSetup()); content.addView(start);
        Button how=btn("🎮 How to Play"); how.setOnClickListener(v->showHow()); content.addView(how);
    }
    void showHow(){
        base("How to Play 🎮","Choose a mode and have fun!");
        content.addView(tv("❓ Who Knows Better\nBoth choose who the question describes. Same choice = +10 points.\n\n🎯 Truth or Dare\nTruth = +5 • Dare = +10\n\n🔥 Couple Challenge\nComplete the challenge = +10. Winner gets the point.\n\n😈 Funny Punishment\nLoser completes a funny punishment = +5 bonus.",18));
        Button b=btn("❤️ Start Game"); b.setOnClickListener(v->showSetup()); content.addView(b);
    }
    void showSetup(){
        base("Let's Get Started! 💕","Enter your names");
        EditText a=new EditText(this); a.setHint("Arjun name"); a.setText(arjun); a.setTextColor(Color.WHITE); a.setHintTextColor(Color.LTGRAY); content.addView(a);
        EditText s=new EditText(this); s.setHint("Sara name"); s.setText(sara); s.setTextColor(Color.WHITE); s.setHintTextColor(Color.LTGRAY); content.addView(s);
        Button c=btn("Continue →"); c.setOnClickListener(v->{ arjun=a.getText().toString().trim(); sara=s.getText().toString().trim(); if(arjun.isEmpty()) arjun="Arjun"; if(sara.isEmpty()) sara="Sara"; showGames(); }); content.addView(c);
    }
    void showGames(){
        base("Choose a Game 🎮",arjun+" ❤️ "+sara); addHeartBurst();
        Button q=btn("❓ Who Knows Better? — 100 Questions"); q.setOnClickListener(v->{qIndex=0;score=0;arjunChoice=-1;answeringArjun=true;showQuestion();}); content.addView(q);
        Button td=btn("🎯 Truth or Dare"); td.setOnClickListener(v->showTruthDare()); content.addView(td);
        Button ch=btn("🔥 Couple Challenge"); ch.setOnClickListener(v->showChallenge()); content.addView(ch);
        Button p=btn("😈 Funny Punishments"); p.setOnClickListener(v->showPunishment()); content.addView(p);
    }
    void showQuestion(){
        String player=answeringArjun?arjun:sara; base("Question "+(qIndex+1)+"/"+questions.length,player+", choose your answer ❤️"); content.addView(tv(questions[qIndex],24));
        Button a=btn("👨 "+arjun); Button s=btn("👩 "+sara); content.addView(a); content.addView(s); a.setOnClickListener(v->answer(0)); s.setOnClickListener(v->answer(1));
    }
    void answer(int choice){
        if(answeringArjun){ arjunChoice=choice; answeringArjun=false; showQuestion(); }
        else { if(choice==arjunChoice) score+=10; answeringArjun=true; qIndex++; if(qIndex>=questions.length) showResult(); else showQuestion(); }
    }
    void showResult(){
        int percent=(score*100)/(questions.length*10); String result=percent>=90?"💖 Perfect Couple":percent>=75?"😍 Super Jodi":percent>=60?"🥰 Cute Couple":percent>=40?"😂 Still Learning Each Other":"🤣 Meeru iddaru dating lo unnara?";
        base("Final Result ❤️",arjun+" & "+sara); addHeartBurst(); TextView p=tv("Compatibility\n"+percent+"%",34); p.setTypeface(null,1); content.addView(p); content.addView(tv(result,24)); content.addView(tv("Score: "+score+" / "+(questions.length*10),20));
        Button again=btn("🔄 Play Again"); again.setOnClickListener(v->{qIndex=0;score=0;arjunChoice=-1;answeringArjun=true;showQuestion();}); content.addView(again); Button home=btn("🏠 Home"); home.setOnClickListener(v->showHome()); content.addView(home);
    }
    void showTruthDare(){
        base("Truth or Dare 🎯",arjun+" ❤️ "+sara); content.addView(tv("Complete it honestly and have fun!",19));
        Button truth=btn("💬 TRUTH"); truth.setOnClickListener(v->{int i=new Random().nextInt(truths.length); showTask("TRUTH 💬",truths[i],5,false);}); content.addView(truth);
        Button dare=btn("🔥 DARE"); dare.setOnClickListener(v->{int i=new Random().nextInt(dares.length); showTask("DARE 🔥",dares[i],10,false);}); content.addView(dare);
        Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back);
    }
    void showTask(String type,String task,int points,boolean timed){
        base(type,"Complete the task"); content.addView(tv(task,25)); addHeartBurst();
        Button done=btn("✅ Completed +"+points); done.setOnClickListener(v->{challengeScore+=points; showModeScore(type,points);}); content.addView(done);
        Button skip=btn("⏭ Skip"); skip.setOnClickListener(v->showTruthDare()); content.addView(skip);
    }
    void showChallenge(){
        base("Couple Challenge 🔥",arjun+" vs "+sara); content.addView(tv("Each challenge has a timer. Complete it together or decide the winner yourselves.",18));
        Button next=btn("🔥 Random Challenge"); next.setOnClickListener(v->{int i=new Random().nextInt(challenges.length); startTimedChallenge(challenges[i]);}); content.addView(next);
        Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back);
    }
    void startTimedChallenge(String task){
        base("Challenge 🔥","30 seconds — Ready?"); content.addView(tv(task,24)); final TextView clock=tv("30",46); content.addView(clock); Button done=btn("🏆 Challenge Complete +10"); content.addView(done); Button cancel=btn("✖ Stop"); content.addView(cancel);
        timer=new CountDownTimer(30000,1000){ public void onTick(long ms){clock.setText(String.valueOf((ms+999)/1000));} public void onFinish(){clock.setText("⏰ Time!"); done.setEnabled(true);} }; timer.start();
        done.setOnClickListener(v->{if(timer!=null)timer.cancel(); challengeScore+=10; showModeScore("🔥 Challenge",10);});
        cancel.setOnClickListener(v->{if(timer!=null)timer.cancel(); showChallenge();});
    }
    void showPunishment(){
        base("Funny Punishment 😈","Loser must complete this!"); int i=new Random().nextInt(punishments.length); content.addView(tv(punishments[i],25));
        Button done=btn("😂 Done! +5 Bonus"); done.setOnClickListener(v->{challengeScore+=5; showModeScore("😈 Punishment",5);}); content.addView(done);
        Button another=btn("🎲 Another Punishment"); another.setOnClickListener(v->showPunishment()); content.addView(another);
        Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back);
    }
    void showModeScore(String mode,int gained){
        base("Nice! 🎉",mode); addHeartBurst(); content.addView(tv("+"+gained+" points",32)); content.addView(tv("Bonus Score: "+challengeScore,20));
        Button again=btn("🎲 Play Again"); again.setOnClickListener(v->{ if(mode.contains("Challenge")) showChallenge(); else if(mode.contains("Punishment")) showPunishment(); else showTruthDare(); }); content.addView(again);
        Button games=btn("🎮 Choose Another Game"); games.setOnClickListener(v->showGames()); content.addView(games);
    }
    @Override protected void onDestroy(){ if(timer!=null) timer.cancel(); super.onDestroy(); }
}
