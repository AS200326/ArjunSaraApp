package com.arjunsara.couplefun;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, subtitle;
    int qIndex = 0, score = 0, arjunChoice = -1, challengeScore = 0;
    boolean answeringArjun = true;
    String arjun = "Arjun", sara = "Sara";
    CountDownTimer timer;
    MediaPlayer music;
    boolean musicOn = true, soundOn = true;
    Random random = new Random();

    final String[] questions = {
        "Who fell in love first?", "Who said 'I love you' first?", "Who is more romantic?",
        "Who misses the other person more?", "Who is more caring?", "Who gets jealous more easily?",
        "Who gets angry first?", "Who apologizes first after a fight?", "Who is more stubborn?",
        "Who talks more?", "Who gives better surprises?", "Who knows the other person better?",
        "Who gives the best hugs?", "Who has the cutest smile?", "Who remembers important dates better?",
        "Who takes longer to get ready?", "Who spends more time on the phone?", "Who makes the other person laugh more?",
        "Who is more protective?", "Who forgives faster?", "Who is more likely to plan a romantic date?",
        "Who would travel anywhere just to meet the other person?", "Who is more likely to say 'I miss you' first?",
        "Who is more likely to call just to hear the partner's voice?", "Who keeps old photos and romantic messages?",
        "Who is more emotional during movies?", "Who is more adventurous?", "Who is more patient?",
        "Who is more likely to choose love over money?", "Who loves the other person more? ❤️"
    };

    final String[] truths = {
        "What was the first thing you liked about your partner? ❤️",
        "What was your first impression of your partner?",
        "What is your favorite memory together?",
        "What is the cutest habit your partner has?",
        "What is the most attractive quality of your partner? 😍",
        "When did you first realize you were in love?",
        "What is one place you want to visit together? ✈️",
        "What is one thing you never want to change about your partner?",
        "What is the sweetest thing your partner has done for you?",
        "What is one dream you want to achieve together? ❤️"
    };

    final String[] dares = {
        "Give your partner 3 genuine compliments. ❤️",
        "Do a funny dance for 20 seconds. 😂",
        "Imitate your partner for 15 seconds. 🤣",
        "Say 'I love you' in 5 different funny styles. 😘",
        "Tell your partner one cute romantic line. 💕",
        "Hum your partner's favorite song for 10 seconds. 🎵",
        "Look at your partner and smile for 15 seconds. 😊",
        "Take a funny couple selfie pose. 📸",
        "Give your partner 3 cute nicknames immediately. 😍",
        "Describe your partner like a movie advertisement. 😂"
    };

    final String[] challenges = {
        "Staring Challenge 👀 — Keep eye contact for 30 seconds without laughing!",
        "No Laugh Challenge 😂 — Keep a serious face for 30 seconds!",
        "Song Challenge 🎵 — Guess your partner's favorite song!",
        "Memory Challenge 🧠 — Tell the details of your first date!",
        "Imitation Challenge 🤣 — Copy your partner's mannerisms!",
        "Compliment Challenge ❤️ — Give as many genuine compliments as possible in 20 seconds!",
        "Emoji Challenge 😍 — Explain a romantic message using only emojis!",
        "Pose Challenge 📸 — Take the best matching couple pose!"
    };

    final String[] punishments = {
        "Give your partner 5 sweet compliments. 💕",
        "Do a 10-second funny dance. 💃",
        "Imitate your partner's favorite dialogue. 🤣",
        "Give your partner a 20-second hug. 🤗",
        "Say one cute apology. 😘",
        "Make one sweet promise to your partner. ❤️"
    };

    final String[] messages = {
        "You are my favorite person in the whole world. ❤️",
        "Every moment with you is special.",
        "My heart always chooses you. 💖",
        "Life feels more beautiful with you.",
        "You are my today and all my tomorrows. ❤️",
        "With you, ordinary moments become beautiful memories.",
        "No matter where life takes us, I want to walk beside you. 🥰",
        "You make my heart smile every day. 💕",
        "Our story is my favorite love story.",
        "Together is my favorite place to be. ❤️"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadSettings();
        showHome();
        if (musicOn) startMusic();
    }

    void loadSettings() {
        android.content.SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        musicOn = p.getBoolean("music", true);
        soundOn = p.getBoolean("sound", true);
    }
    void saveSettings() {
        getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("music", musicOn).putBoolean("sound", soundOn).apply();
    }
    void startMusic() {
        if (!musicOn || music != null) return;
        int id = getResources().getIdentifier("romantic_music", "raw", getPackageName());
        if (id == 0) return;
        music = MediaPlayer.create(this, id);
        if (music != null) { music.setLooping(true); music.setVolume(.22f, .22f); music.start(); }
    }
    void stopMusic() { if (music != null) { music.stop(); music.release(); music = null; } }
    void beep() { if (!soundOn) return; try { android.media.ToneGenerator tg = new android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 70); tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 120); new Handler().postDelayed(tg::release, 180); } catch(Exception ignored) {} }

    TextView tv(String text, int size) { TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); t.setPadding(16,12,16,12); return t; }
    Button btn(String text) { Button b = new Button(this); b.setText(text); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(16,8,16,8); GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(233,30,99)); g.setCornerRadius(60); b.setBackground(g); int h=(int)(60*getResources().getDisplayMetrics().density); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h); p.setMargins(20,6,20,6); b.setLayoutParams(p); return b; }
    void base(String heading, String sub) { root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20); GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(27,18,48),Color.rgb(106,27,154)}); root.setBackground(bg); ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER_HORIZONTAL); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); title=tv(heading,30); title.setTypeface(null,1); content.addView(title); subtitle=tv(sub,16); content.addView(subtitle); animate(title); }
    void animate(View v) { v.setAlpha(0f); v.setScaleX(.94f); v.setScaleY(.94f); v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).start(); }
    void addHeartBurst() { TextView hearts=tv("❤️  💕  💖  💗  💓  💕  ❤️",25); content.addView(hearts); hearts.animate().alpha(0f).translationY(-25).setDuration(900).start(); }

    void showHome() {
        base("Mogudu Pellam ❤️", "Arjun & Sara • Couple Fun Game"); addHeartBurst();
        Button birthday=btn("🎂 Birthday Surprise"); birthday.setOnClickListener(v->showBirthday()); content.addView(birthday);
        Button start=btn("❤️ Start Love Quiz"); start.setOnClickListener(v->showSetup()); content.addView(start);
        Button messages=btn("💌 Love Messages"); messages.setOnClickListener(v->showMessages()); content.addView(messages);
        Button history=btn("🏆 Our Score"); history.setOnClickListener(v->showHistory()); content.addView(history);
        Button settings=btn("⚙️ Settings"); settings.setOnClickListener(v->showSettings()); content.addView(settings);
        Button how=btn("🎮 How to Play"); how.setOnClickListener(v->showHow()); content.addView(how);
    }
    void showHow() { base("How to Play 🎮", "Choose a mode and have fun!"); content.addView(tv("❓ Who Knows Better\nBoth choose who the question describes. Same choice = +10 points.\n\n🎯 Truth or Dare\nTruth = +5 • Dare = +10\n\n🔥 Couple Challenge\nComplete the challenge = +10.\n\n😈 Funny Punishment\nComplete a funny punishment = +5 bonus.",18)); Button b=btn("❤️ Start Game"); b.setOnClickListener(v->showSetup()); content.addView(b); }
    void showSetup() { base("Let's Get Started! 💕", "Enter your names"); EditText a=new EditText(this); a.setHint("First partner name"); a.setText(arjun); a.setTextColor(Color.WHITE); a.setHintTextColor(Color.LTGRAY); content.addView(a); EditText s=new EditText(this); s.setHint("Second partner name"); s.setText(sara); s.setTextColor(Color.WHITE); s.setHintTextColor(Color.LTGRAY); content.addView(s); Button c=btn("Continue →"); c.setOnClickListener(v->{arjun=a.getText().toString().trim(); sara=s.getText().toString().trim(); if(arjun.isEmpty()) arjun="Arjun"; if(sara.isEmpty()) sara="Sara"; showGames();}); content.addView(c); }

    void showGames() { base("Choose a Game 🎮", arjun+" ❤️ "+sara); addHeartBurst(); Button q=btn("❓ Who Knows Better? — 30 Questions"); q.setOnClickListener(v->{qIndex=0;score=0;arjunChoice=-1;answeringArjun=true;showQuestion();}); content.addView(q); Button td=btn("🎯 Truth or Dare"); td.setOnClickListener(v->showTruthDare()); content.addView(td); Button ch=btn("🔥 Couple Challenge"); ch.setOnClickListener(v->showChallenge()); content.addView(ch); Button p=btn("😈 Funny Punishments"); p.setOnClickListener(v->showPunishment()); content.addView(p); Button m=btn("💌 Love Messages"); m.setOnClickListener(v->showMessages()); content.addView(m); Button h=btn("🏆 Score History"); h.setOnClickListener(v->showHistory()); content.addView(h); Button home=btn("🏠 Home"); home.setOnClickListener(v->showHome()); content.addView(home); }

    void showQuestion() { String player=answeringArjun?arjun:sara; base("Question "+(qIndex+1)+"/"+questions.length,player+", choose your answer ❤️"); content.addView(tv(questions[qIndex],24)); Button a=btn("👨 "+arjun); Button s=btn("👩 "+sara); content.addView(a); content.addView(s); a.setOnClickListener(v->answer(0)); s.setOnClickListener(v->answer(1)); }
    void answer(int choice) { beep(); if(answeringArjun){arjunChoice=choice; answeringArjun=false; showQuestion();} else {if(choice==arjunChoice) score+=10; answeringArjun=true; qIndex++; if(qIndex>=questions.length) showResult(); else showQuestion();} }
    void showResult() { int percent=(score*100)/(questions.length*10); String result=percent>=90?"💖 Perfect Match! You two are made for each other!":percent>=75?"🥰 Amazing Connection! Your love is strong!":percent>=50?"❤️ Good Match! Keep creating beautiful memories together!":"😂 You need more couple time! Keep learning about each other!"; saveQuiz(percent); base("Quiz Completed! ❤️",arjun+" & "+sara); addHeartBurst(); content.addView(tv("Love Score\n"+percent+"%",34)); content.addView(tv(result,22)); content.addView(tv("Score: "+score+" / "+(questions.length*10),20)); Button again=btn("🔄 Play Again"); again.setOnClickListener(v->{qIndex=0;score=0;arjunChoice=-1;answeringArjun=true;showQuestion();}); content.addView(again); Button messages=btn("💌 Love Message"); messages.setOnClickListener(v->showMessages()); content.addView(messages); Button home=btn("🏠 Home"); home.setOnClickListener(v->showHome()); content.addView(home); }
    void saveQuiz(int percent) { android.content.SharedPreferences p=getSharedPreferences("scores",MODE_PRIVATE); int best=p.getInt("best",0), count=p.getInt("count",0); p.edit().putInt("best",Math.max(best,percent)).putInt("last",percent).putInt("count",count+1).apply(); }
    void showHistory() { android.content.SharedPreferences p=getSharedPreferences("scores",MODE_PRIVATE); int last=p.getInt("last",0),best=p.getInt("best",0),count=p.getInt("count",0); base("Our Score 🏆",arjun+" ❤️ "+sara); addHeartBurst(); content.addView(tv("Latest Love Score\n"+last+"%",28)); content.addView(tv("Best Love Score\n"+best+"%",28)); content.addView(tv("Quizzes Completed\n"+count,22)); Button back=btn("← Back to Home"); back.setOnClickListener(v->showHome()); content.addView(back); Button reset=btn("🗑 Reset Score"); reset.setOnClickListener(v->{getSharedPreferences("scores",MODE_PRIVATE).edit().clear().apply(); showHistory();}); content.addView(reset); }

    void showTruthDare() { base("Truth or Dare 🎯",arjun+" ❤️ "+sara); content.addView(tv("Answer honestly and have fun!",19)); Button truth=btn("💬 TRUTH +5"); truth.setOnClickListener(v->{int i=random.nextInt(truths.length); showTask("TRUTH 💬",truths[i],5);}); content.addView(truth); Button dare=btn("🔥 DARE +10"); dare.setOnClickListener(v->{int i=random.nextInt(dares.length); showTask("DARE 🔥",dares[i],10);}); content.addView(dare); Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back); }
    void showTask(String type,String task,int points) { base(type,"Complete the task"); content.addView(tv(task,25)); addHeartBurst(); Button done=btn("✅ Completed +"+points); done.setOnClickListener(v->{challengeScore+=points; beep(); showModeScore(type,points);}); content.addView(done); Button skip=btn("⏭ Skip"); skip.setOnClickListener(v->showTruthDare()); content.addView(skip); }
    void showChallenge() { base("Couple Challenge 🔥",arjun+" vs "+sara); content.addView(tv("Complete the challenge together and decide the winner!",18)); Button next=btn("🔥 Random Challenge"); next.setOnClickListener(v->{int i=random.nextInt(challenges.length); startTimedChallenge(challenges[i]);}); content.addView(next); Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back); }
    void startTimedChallenge(String task) { base("Challenge 🔥","30 seconds — Ready?"); content.addView(tv(task,24)); final TextView clock=tv("30",46); content.addView(clock); Button done=btn("🏆 Challenge Complete +10"); content.addView(done); Button cancel=btn("✖ Stop"); content.addView(cancel); timer=new CountDownTimer(30000,1000){public void onTick(long ms){clock.setText(String.valueOf((ms+999)/1000));} public void onFinish(){clock.setText("⏰ Time!");}}; timer.start(); done.setOnClickListener(v->{if(timer!=null)timer.cancel(); challengeScore+=10; beep(); showModeScore("🔥 Challenge",10);}); cancel.setOnClickListener(v->{if(timer!=null)timer.cancel(); showChallenge();}); }
    void showPunishment() { base("Funny Punishment 😈","Loser must complete this!"); int i=random.nextInt(punishments.length); content.addView(tv(punishments[i],25)); Button done=btn("😂 Done! +5 Bonus"); done.setOnClickListener(v->{challengeScore+=5; showModeScore("😈 Punishment",5);}); content.addView(done); Button another=btn("🎲 Another Punishment"); another.setOnClickListener(v->showPunishment()); content.addView(another); Button back=btn("← Back"); back.setOnClickListener(v->showGames()); content.addView(back); }
    void showModeScore(String mode,int gained) { base("Nice! 🎉",mode); addHeartBurst(); content.addView(tv("+"+gained+" points",32)); content.addView(tv("Bonus Score: "+challengeScore,20)); Button again=btn("🎲 Play Again"); again.setOnClickListener(v->{if(mode.contains("Challenge"))showChallenge();else if(mode.contains("Punishment"))showPunishment();else showTruthDare();}); content.addView(again); Button games=btn("🎮 Choose Another Game"); games.setOnClickListener(v->showGames()); content.addView(games); }

    void showMessages() { base("Love Messages 💌",arjun+" ❤️ "+sara); addHeartBurst(); TextView msg=tv(messages[random.nextInt(messages.length)],24); content.addView(msg); Button next=btn("💌 Next Message"); next.setOnClickListener(v->showMessages()); content.addView(next); Button back=btn("← Home"); back.setOnClickListener(v->showHome()); content.addView(back); }
    void showBirthday() { base("Happy Birthday 🎂❤️", "A special message for Chinna Papa"); addHeartBurst(); content.addView(tv("Happy Birthday Chinna Papa ❣️",30)); content.addView(tv("Today is all about you. Keep smiling, keep shining, and always stay happy. ❤️\n\nMay every dream in your heart come true, and may our beautiful memories keep growing. 🥰",20)); Button surprise=btn("🎉 One More Surprise"); surprise.setOnClickListener(v->{addHeartBurst(); Toast.makeText(this,"You are loved more than words can say! ❤️",Toast.LENGTH_LONG).show();}); content.addView(surprise); Button back=btn("🏠 Home"); back.setOnClickListener(v->showHome()); content.addView(back); }
    void showSettings() { base("Settings ⚙️","Customize your couple experience"); Switch musicSwitch=new Switch(this); musicSwitch.setText("🎵 Background Music"); musicSwitch.setTextColor(Color.WHITE); musicSwitch.setTextSize(18); musicSwitch.setChecked(musicOn); musicSwitch.setPadding(16,16,16,16); content.addView(musicSwitch); musicSwitch.setOnCheckedChangeListener((b,c)->{musicOn=c;saveSettings();if(c)startMusic();else stopMusic();}); Switch soundSwitch=new Switch(this); soundSwitch.setText("🔊 Sound Effects"); soundSwitch.setTextColor(Color.WHITE); soundSwitch.setTextSize(18); soundSwitch.setChecked(soundOn); soundSwitch.setPadding(16,16,16,16); content.addView(soundSwitch); soundSwitch.setOnCheckedChangeListener((b,c)->{soundOn=c;saveSettings();}); Button reset=btn("🗑 Reset All Scores"); reset.setOnClickListener(v->{getSharedPreferences("scores",MODE_PRIVATE).edit().clear().apply();Toast.makeText(this,"Scores reset.",Toast.LENGTH_SHORT).show();}); content.addView(reset); Button about=btn("ℹ️ About"); about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Arjun & Sara ❤️").setMessage("Mogudu Pellam — a romantic couple fun game with quizzes, challenges, love messages and birthday surprises.").setPositiveButton("OK",null).show()); content.addView(about); Button back=btn("← Home"); back.setOnClickListener(v->showHome()); content.addView(back); }

    @Override protected void onPause(){ super.onPause(); if(isFinishing()) stopMusic(); }
    @Override protected void onResume(){ super.onResume(); if(musicOn && music==null) startMusic(); }
    @Override protected void onDestroy(){ if(timer!=null)timer.cancel(); stopMusic(); super.onDestroy(); }
}
