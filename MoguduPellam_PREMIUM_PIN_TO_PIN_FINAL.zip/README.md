# Mogudu Pellam – Premium Pin-to-Pin UI Target

This package is the Android project for Mogudu Pellam with the premium romantic UI target based on the supplied reference image.

Included:
- 100+ Couple Questions
- 35 Birthday Wishes
- 35 Anniversary Wishes
- Daily Love Message
- Spin the Wheel
- Truth or Dare
- Couple Challenge
- Funny Punishment
- Love Meter
- XP + Levels + Achievements
- Coins & Rewards
- Memories + Captions
- Enhanced Our Love Story + story card + share
- Surprise Box
- Music + Sound Effects
- Hearts, confetti and smooth animations
- Share Result
- Dark / Light mode
- Responsive web edition
- GitHub Actions build workflow
