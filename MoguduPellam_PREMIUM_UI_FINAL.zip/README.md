# Arjun & Sara — Mogudu Pellam

English-only romantic couple game app.

Features:
- Birthday Surprise with “Happy Birthday Chinna Papa ❣️”
- 30-question Who Knows Better quiz
- Love compatibility score and score history
- Truth or Dare
- Timed Couple Challenges
- Funny Punishments
- Random Love Messages
- Background music and sound-effect toggles
- Romantic animations and the Arjun & Sara launcher logo


## Animations
Added screen entrance animations, button press animations, heart bursts, completion confetti, and countdown pulse effects.
